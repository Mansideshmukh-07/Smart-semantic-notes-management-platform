# backend/notes_api/views.py
import os
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.parsers import MultiPartParser, FormParser
from django.conf import settings
from django.core.files.storage import default_storage
from sentence_transformers import SentenceTransformer

# ── Imports for your existing components ───────────────────────────────────
from .serializers import SignupSerializer
from .models import UploadedFile, NoteChunk

# ── Imports pointing to your new package folder ────────────────────────────
from .preprocessing_file.read_file import read_file
from .preprocessing_file.preprocess import preprocess
from .preprocessing_file.text_chunk import chunk

# Initialize the local embedding model once when the server boots up (384 dimensions)
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')


# ── Your Existing Views (Kept Exactly as You Had Them) ─────────────────────

class SignupView(APIView):
    permission_classes = [AllowAny] # Ensures anyone can hit this endpoint to register

    def post(self, request):
        serializer = SignupSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "User created"},
                status=status.HTTP_201_CREATED
            )

        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST
        )


class ProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({
            "id": request.user.id,
            "username": request.user.username,
            "email": request.user.email,
        })


# ── Your New Modular File Processing Pipeline View ────────────────────────

class FileUploadAndProcessView(APIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        file_obj = request.FILES.get('file')
        subject_name = request.data.get('subject', 'General').strip()
        category = request.data.get('file_type', 'digital').strip().lower() # expects "digital" or "handwritten"

        if not file_obj:
            return Response({"error": "No file uploaded"}, status=status.HTTP_400_BAD_REQUEST)

        # 1. Save the incoming raw file to the local disk media directory
        saved_path = default_storage.save(os.path.join('media', file_obj.name), file_obj)
        full_local_path = os.path.join(settings.BASE_DIR, saved_path)

        # 2. Register the Document meta-record into PostgreSQL
        uploaded_file_record = UploadedFile.objects.create(
            user=request.user,
            filename=file_obj.name,
            subject=subject_name,
            file_type=category,
            file_path=full_local_path
        )

        # 3. Text Extraction based on the selected category
        raw_extracted_text = ""
        
        if category == "digital":
            try:
                # Use YOUR universal read_file package to extract PDF, DOCX, or TXT
                raw_extracted_text = read_file(full_local_path)
            except Exception as e:
                return Response({"error": f"Read pipeline failed: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
        
        elif category == "handwritten":
            # Temporary placeholder for your offline custom Tesseract pipeline updates
            raw_extracted_text = "Handwritten document placeholder. OCR pipeline bypassed for now."

        # 4. Use YOUR preprocess script to strip formatting noise and bullet patterns
        cleaned_text = preprocess(raw_extracted_text, verbose=False)

        if not cleaned_text.strip():
            return Response({"error": "No processable text extracted from this document"}, status=status.HTTP_400_BAD_REQUEST)

        # 5. Use YOUR 4-step hybrid chunking script (Section -> Paragraph -> Merge -> Overlap)
        text_chunks = chunk(
            cleaned_text,
            chunk_size=250,
            overlap=40,
            min_words=20,
            verbose=False
        )

        # 6. Generate vectors using SentenceTransformer and save chunks directly to the DB
        for idx, text_block in enumerate(text_chunks):
            vector_embedding = embedding_model.encode(text_block).tolist()
            
            NoteChunk.objects.create(
                file=uploaded_file_record,
                chunk_text=text_block,
                chunk_index=idx,
                embedding=vector_embedding
            )

        return Response({
            "message": f"Successfully executed processing pipeline inside preprocessing_file pack!",
            "file_id": uploaded_file_record.id,
            "subject": uploaded_file_record.subject,
            "file_type": uploaded_file_record.file_type,
            "total_chunks_saved": len(text_chunks)
        }, status=status.HTTP_201_CREATED)


"""from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from .serializers import SignupSerializer

class SignupView(APIView):

    def post(self, request):

        serializer = SignupSerializer(
            data=request.data
        )

        if serializer.is_valid():
            serializer.save()

            return Response(
                {"message": "User created"},
                status=status.HTTP_201_CREATED
            )

        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST
        )

class ProfileView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({
            "id": request.user.id,
            "username": request.user.username,
            "email": request.user.email,
        })

"""
