from django.urls import path
from .views import SignupView, ProfileView, FileUploadAndProcessView
urlpatterns = [
    path('signup/', SignupView.as_view()),
    path('profile/', ProfileView.as_view()),
    #Appended our modular cleaning/chunking file pipeline right below:
    path('files/upload/', FileUploadAndProcessView.as_view()),
]
